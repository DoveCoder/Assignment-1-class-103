
// Variables
let pi = 3.14;
let message = "Hello, World";
let radius = "r";
let double = 2;
let algebra = "is fun";
let firstName = "julian";
let lastName = "smith";
let guest = "derek";
let role = "developer"
let animal = "dog";
const one = 1;
const two = 2;
const three = 3;
const four = 4;
const five = 5;
const six = 6;
const seven = 7;
const eight = 8;
const nine = 9;
var count = "bang";

hiddenMessage = `<p>${message}! programming ${algebra}. I ${firstName} ${lastName} 
want to be a ${role} I have an Akita who is my favorite ${animal}. My friend is ${guest}
you will need this equation to solve his head shape (${double})${pi}${radius}^2.
Well im off to the races in ${one}...${two}...${three}...${four}...${five}...${six}...
${seven}...${eight}...${nine}...${count}!!</p>`;

console.log(hiddenMessage);

document.querySelector('main').innerHTML = hiddenMessage;
